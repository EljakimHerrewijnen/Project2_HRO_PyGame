import pygame
from Node import *

class Player:
    def __init__(self, id, name, card):
        self.Pl_id = id
        self.Pl_name = name
        self.Gamecard = card